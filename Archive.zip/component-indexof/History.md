
0.0.3 / 2014-02-10
==================

  * package: rename to "component-indexof"

0.0.2 / 2013-11-13
==================

  * add repository field to package.json
  * handle node lists
  * added mocha tests
  * Update Makefile

0.0.1 / 2013-01-22
==================

 * Initial commmit
 * Add `package.json`
