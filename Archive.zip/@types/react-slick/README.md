# Installation
> `npm install --save @types/react-slick`

# Summary
This package contains type definitions for react-slick ( https://github.com/akiran/react-slick ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-slick

Additional Details
 * Last updated: Fri, 03 May 2019 10:37:16 GMT
 * Dependencies: @types/react
 * Global values: none

# Credits
These definitions were written by Andrey Balokha <https://github.com/andrewBalekha>, Giedrius Grabauskas <https://github.com/GiedriusGrabauskas>, Andrew Makarov <https://github.com/r3nya>, Shannor Trotty <https://github.com/Shannor>.
