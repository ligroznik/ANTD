var convert = require('./convert'),
    func = convert('isEqual', require('../isEqual'));

func.placeholder = require('./placeholder');
module.exports = func;
