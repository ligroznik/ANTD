var convert = require('./convert'),
    func = convert('padChars', require('../pad'));

func.placeholder = require('./placeholder');
module.exports = func;
