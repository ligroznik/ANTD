var stringConvert = {
  hyphen2camel: require('./hyphen2camel'),
  camel2hyphen : require('./camel2hyphen')
};

module.exports = stringConvert;