# History
----

## 2.9.0 / 2019-07-09

- CSSMotion support forward ref to render props

## 2.8.0 / 2019-04-29

- `keys` on CSSMotionList can be an object

## 2.7.0 / 2019-04-29

- add CSSMotionList component

## 2.6.0 / 2018-11-26

- add CSSMotion component

## 2.3.0 / 2016-07-05

- support null/undefined child: https://github.com/react-component/animate/pull/11

## 2.2.0 / 2016-06-28

- support transitionName as object

## 2.1.0 / 2016-06-16

- make onEnter/onLeave/onAppear async