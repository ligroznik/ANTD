# History

## 2.0.0

- remove props like `onTouchStart`, `onTouchMove`, `onTouchEnd`, `onTouchCancel`,`onMouseDown`, `onMouseUp`, `onMouseLeave` from `TouchFeedback`
- fix the problem that `TouchFeedback` component will cover the children's events

## 1.0.2

- support activeStyle=false to disabled `touchfeedback`

## 0.0.1

init project
