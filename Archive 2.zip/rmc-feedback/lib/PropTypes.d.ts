export interface ITouchProps {
    disabled?: boolean;
    activeClassName?: string;
    activeStyle?: any;
    children?: any;
}
export interface ITouchState {
    active: boolean;
}
