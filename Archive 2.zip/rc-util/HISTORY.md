# History
----

## 4.8.0 / 2019-07-09

- add findDOMNode to check if a DOM first and then use native findDOMNode

## 4.7.0 / 2019-07-08

- add PortalWrapper to support body scroll control

## 4.6.0 / 2016-10-15

- addDOMEventListener support option

## 3.4.0 / 2016-08-16

- add getScrollBarSize


## 3.3.0 / 2016-07-18

- add getContainerRenderMixin
