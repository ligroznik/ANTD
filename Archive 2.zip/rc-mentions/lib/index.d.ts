import Mentions from './Mentions';
export default Mentions;
