# History
----

## 0.3.0 / 2019-05-14

- Support `placement` prop.

## 0.2.0 / 2019-05-08

- Support `rows` prop.

## 0.1.0 / 2019-05-08

- Initial release.