import React from 'react';
export default class ToolbarLine extends React.Component<any, any> {
    render(): any;
}
