import { BlockMap, ContentState } from 'draft-js';
export default function customHTML2Content(HTML: any, contentState: ContentState): BlockMap;
