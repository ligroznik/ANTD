export declare type DraftHandleValue = 'handled' | 'not-handled';
export default function handlePastedText(text: string, html?: string): DraftHandleValue;
